package com.codearqui.serviceinventory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicesInventoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
