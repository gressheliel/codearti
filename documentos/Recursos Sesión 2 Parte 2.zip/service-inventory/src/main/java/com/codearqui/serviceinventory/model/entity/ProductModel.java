package com.codearqui.serviceinventory.model.entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.relational.core.mapping.Table;

import java.math.BigDecimal;

@Getter
@Setter
@Table("products")
public class ProductModel {
    private int id;
    private String code;
    private String productName;
    private  int stock;
    private BigDecimal price;
}
